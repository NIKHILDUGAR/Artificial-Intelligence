import pandas as pd
import matplotlib.pyplot as plt
df=pd.read_csv("C://Users//nikhi//Desktop//late_early.csv")
import skfuzzy as fuzz
m=df.iloc[:,[1]]
m=np.array(m)
n=df.iloc[:,[2]]
n=np.array(n)
a=[7,7.5,8, 8.5 , 9 , 9.5 ,10 ,10.5 ,11 ,11.5,12 ]
mfz=fuzz.trimf(m.flatten(),[0,20,40])
print("Late - ",mfz)
nfz=fuzz.trimf(n.flatten(),[0,20,40])
print("Early - ",nfz)
zfz=np.fmin(mfz, nfz)
print("intersection--",zfz)
plt.subplot(2, 1, 1)
plt.plot(a,mfz)
plt.title('Late and Early membership functions ')
plt.ylabel('Late in fuzzy function')
plt.subplot(2, 1, 2)
plt.plot(a,nfz)
plt.xlabel('Time->')
plt.ylabel('Early in fuzzy function')
plt.show()